import React, { useEffect, useState } from 'react'
import { NavLink, Route, Routes, useNavigate } from 'react-router-dom'
import { seedIfEmpty } from './db'
import { AuthProvider, useAuth } from './auth'
import Dashboard from './pages/Dashboard'
import Rojmel from './pages/Rojmel'
import Parties from './pages/Parties'
import Invoices from './pages/Invoices'
import MetalRates from './pages/MetalRates'
import Reports from './pages/Reports'
import Settings from './pages/Settings'
import Login from './pages/Login'

function Shell(){
  const nav = useNavigate()
  const {user, logout} = useAuth()
  const [online, setOnline] = useState(navigator.onLine)
  useEffect(()=>{
    const h = ()=>setOnline(navigator.onLine)
    window.addEventListener('online', h); window.addEventListener('offline', h)
    return ()=>{window.removeEventListener('online', h);window.removeEventListener('offline', h)}
  },[])
  return (
    <div>
      <header className="appbar">
        <div className="row">
          <strong>Jewellery Rojmel</strong>
          <span className="pill">{online? 'Online' : 'Offline'}</span>
        </div>
        <div className="row">
          {user ? <>
            <span className="muted">Role: {user.role}</span>
            <button className="btn" onClick={()=>{logout(); nav('/login')}}>Logout</button>
          </> : <button className="btn" onClick={()=>nav('/login')}>Login</button>}
        </div>
      </header>
      <div className="container">
        <aside className="sidebar">
          {['/','/rojmel','/parties','/invoices','/metal-rates','/reports','/settings'].map((path, i)=>{
            const labels = ['Dashboard','Rojmel','Parties','Invoices','Metal Rates','Reports','Settings']
            return <NavLink key={path} to={path} className={({isActive})=>`navlink ${isActive?'active':''}`}>{labels[i]}</NavLink>
          })}
        </aside>
        <main className="grid">
          <Routes>
            <Route path="/" element={<Dashboard/>}/>
            <Route path="/rojmel" element={<Rojmel/>}/>
            <Route path="/parties" element={<Parties/>}/>
            <Route path="/invoices" element={<Invoices/>}/>
            <Route path="/metal-rates" element={<MetalRates/>}/>
            <Route path="/reports" element={<Reports/>}/>
            <Route path="/settings" element={<Settings/>}/>
            <Route path="/login" element={<Login/>}/>
          </Routes>
        </main>
      </div>
      <footer className="footer">© {new Date().getFullYear()} Jewellery Rojmel – Offline-first PWA demo.</footer>
    </div>
  )
}

export default function App(){
  useEffect(()=>{seedIfEmpty()},[])
  return <AuthProvider><Shell/></AuthProvider>
}
