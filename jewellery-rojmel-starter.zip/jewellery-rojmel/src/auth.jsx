import React, {createContext, useContext, useEffect, useState} from 'react'
import { db } from './db'

const Ctx = createContext(null)
export function AuthProvider({children}){
  const [user, setUser] = useState(null)
  useEffect(()=>{(async()=>{await db.open()})()},[])
  const login = async (mobile, pin)=>{
    const u = await db.users.where({mobile, pin_hash: pin}).first()
    if(!u) throw new Error('Invalid credentials')
    setUser(u)
    await db.users.update(u.id, { last_login_at: new Date().toISOString() })
  }
  const logout = ()=> setUser(null)
  return <Ctx.Provider value={{user, login, logout}}>{children}</Ctx.Provider>
}
export function useAuth(){return useContext(Ctx)}
