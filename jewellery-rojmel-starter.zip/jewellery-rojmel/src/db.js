import Dexie from 'dexie'
export const db = new Dexie('jrrokad')
db.version(1).stores({
  users: '++id, mobile, pin_hash, role, last_login_at',
  parties: '++id, name, type, phone, gstin, opening_balance, current_balance, created_at, updated_at',
  transactions: '++id, date, entry_no, jamaa_or_naama, party_id, amount_inr, mode, notes',
  invoices: '++id, invoice_no, date, party_id, subtotal_inr, discount_inr, tax_inr, total_inr, received_inr, balance_inr',
  invoiceItems: '++id, invoice_id, sku, item_name, metal_type, purity_kt, weight_g, quantity, making_rate_type, making_rate_value, stone_detail, line_total_inr',
  inventory: '++id, sku, item_name, design_code, category, metal_type, purity_kt, weight_g, quantity, rate_inr, stock_in, stock_out, updated_at',
  metalRates: '++id, date, metal_type, purity_kt, rate_per_g_inr'
})
export async function seedIfEmpty(){
  const count = await db.parties.count()
  if(count>0) return
  const now = new Date().toISOString().slice(0,10)
  const custId = await db.parties.add({name:'Walk-in Customer', type:'customer', phone:'', gstin:'', opening_balance:0, current_balance:0, created_at:now, updated_at:now})
  await db.metalRates.bulkAdd([
    {date:now, metal_type:'Gold', purity_kt:22, rate_per_g_inr:6200},
    {date:now, metal_type:'Silver', purity_kt:100, rate_per_g_inr:80}
  ])
  await db.transactions.bulkAdd([
    {date:now, entry_no:1, jamaa_or_naama:'receipt', party_id:custId, amount_inr:125000, mode:'cash', notes:'Advance' },
    {date:now, entry_no:2, jamaa_or_naama:'payment', party_id:custId, amount_inr:25000, mode:'cash', notes:'Rent' }
  ])
  await db.users.add({mobile:'9999999999', pin_hash:'1234', role:'admin', last_login_at:now})
}
