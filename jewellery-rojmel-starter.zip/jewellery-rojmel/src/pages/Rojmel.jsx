import React, { useEffect, useMemo, useState } from 'react'
import { db } from '../db'
import * as XLSX from 'xlsx'
const currency = n => new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR'}).format(n||0)

export default function Rojmel(){
  const [rows, setRows] = useState([])
  const [form, setForm] = useState({date:new Date().toISOString().slice(0,10), entry_no:'', party_id:'', amount_inr:0, mode:'cash', notes:'', jamaa_or_naama:'receipt'})
  const [parties, setParties] = useState([])
  const [range, setRange] = useState({from:new Date(Date.now()-7*864e5).toISOString().slice(0,10), to:new Date().toISOString().slice(0,10)})
  useEffect(()=>{(async()=>{ setRows(await db.transactions.toArray()); setParties(await db.parties.toArray()) })()},[])

  const filtered = useMemo(()=> rows.filter(r => r.date>=range.from && r.date<=range.to).sort((a,b)=>(a.date>b.date?1:-1)),[rows,range])
  const totals = useMemo(()=> filtered.reduce((acc,r)=>{acc[r.jamaa_or_naama==='receipt'?'j':'n']+=Number(r.amount_inr||0); return acc},{j:0,n:0}),[filtered])

  async function addRow(){
    const payload = {...form, entry_no: Number(form.entry_no|| (rows.length+1)), amount_inr:Number(form.amount_inr)}
    payload.party_id = Number(payload.party_id||0)
    const id = await db.transactions.add(payload)
    setRows([...rows,{...payload,id}])
    setForm(f=>({...f, entry_no:'', party_id:'', amount_inr:0, notes:''}))
  }
  async function remove(id){
    await db.transactions.delete(id)
    setRows(rows.filter(r=>r.id!==id))
  }
  function exportExcel(){
    const ws = XLSX.utils.json_to_sheet(filtered)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, 'Rojmel')
    XLSX.writeFile(wb, `rojmel_${range.from}_${range.to}.xlsx`)
  }
  return (
    <div className="grid">
      <div className="card">
        <div className="row">
          <div className="stack" style={{flex:1}}>
            <label>Date</label>
            <input className="input" type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/>
          </div>
          <div className="stack"><label>Entry No</label><input className="input" type="number" value={form.entry_no} onChange={e=>setForm({...form,entry_no:e.target.value})}/></div>
          <div className="stack" style={{flex:1}}>
            <label>Party</label>
            <select className="select" value={form.party_id} onChange={e=>setForm({...form,party_id:e.target.value})}>
              <option value="">Select party</option>
              {parties.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div className="stack"><label>Type</label>
            <select className="select" value={form.jamaa_or_naama} onChange={e=>setForm({...form,jamaa_or_naama:e.target.value})}>
              <option value="receipt">Jamaa (Receipt)</option>
              <option value="payment">Naama (Payment)</option>
            </select>
          </div>
          <div className="stack"><label>Amount (₹)</label><input className="input" type="number" value={form.amount_inr} onChange={e=>setForm({...form,amount_inr:e.target.value})}/></div>
          <div className="stack"><label>Mode</label>
            <select className="select" value={form.mode} onChange={e=>setForm({...form,mode:e.target.value})}>
              <option>cash</option><option>bank</option><option>upi</option>
            </select>
          </div>
          <div className="stack" style={{flex:2}}><label>Notes</label><input className="input" value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})}/></div>
          <div className="right"><button className="btn primary" onClick={addRow}>Add Entry</button></div>
        </div>
      </div>

      <div className="row">
        <div className="card" style={{flex:1}}>
          <div className="row">
            <div className="stack"><label>From</label><input className="input" type="date" value={range.from} onChange={e=>setRange({...range,from:e.target.value})}/></div>
            <div className="stack"><label>To</label><input className="input" type="date" value={range.to} onChange={e=>setRange({...range,to:e.target.value})}/></div>
            <div className="right" style={{flex:1}}><button className="btn" onClick={exportExcel}>Export Excel</button></div>
          </div>
        </div>
        <div className="card" style={{minWidth:280}}>
          <div className="stack">
            <div>Total Jamaa: <strong>{currency(totals.j)}</strong></div>
            <div>Total Naama: <strong>{currency(totals.n)}</strong></div>
            <div>Closing Balance: <strong>{currency(totals.j - totals.n)}</strong></div>
          </div>
        </div>
      </div>

      <div className="card">
        <table className="table">
          <thead><tr>
            <th>Entry</th><th>Date</th><th>Party</th><th>Type</th><th>Amount</th><th>Mode</th><th>Notes</th><th></th>
          </tr></thead>
          <tbody>
            {filtered.map(r=>(
              <tr key={r.id}>
                <td>{r.entry_no}</td><td>{r.date}</td>
                <td>{(parties.find(p=>p.id===r.party_id)||{}).name||'-'}</td>
                <td>{r.jamaa_or_naama}</td><td>{currency(r.amount_inr)}</td><td>{r.mode}</td><td>{r.notes}</td>
                <td><button className="btn danger" onClick={()=>remove(r.id)}>Delete</button></td>
              </tr>
            ))}
            {filtered.length===0 && <tr><td colSpan="8" className="muted">No entries.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  )
}
