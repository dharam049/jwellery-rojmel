import React, { useEffect, useState } from 'react'
import { db } from '../db'
import * as XLSX from 'xlsx'
export default function Reports(){
  const [ledger, setLedger] = useState([])
  useEffect(()=>{(async()=> setLedger(await db.transactions.toArray()))()},[])
  function exportExcel(){
    const ws = XLSX.utils.json_to_sheet(ledger)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, 'Rojmel')
    XLSX.writeFile(wb, 'reports.xlsx')
  }
  return (
    <div className="grid">
      <div className="card"><div className="row"><div className="stack"><div className="muted">Rojmel entries</div><strong>{ledger.length}</strong></div><div className="right"><button className="btn" onClick={exportExcel}>Export Excel</button></div></div></div>
      <div className="card"><div className="muted">Party-wise ledger and P&L can be added here with more calculations.</div></div>
    </div>
  )
}
