import React, { useEffect, useMemo, useState } from 'react'
import { db } from '../db'
import { jsPDF } from 'jspdf'

export default function Invoices(){
  const [rows, setRows] = useState([])
  const [parties, setParties] = useState([])
  const [items, setItems] = useState([{item_name:'Gold Ring', metal_type:'Gold', purity_kt:22, weight_g:5, quantity:1, making_rate_type:'per_g', making_rate_value:150, line_total_inr:0}])
  const [form, setForm] = useState({date:new Date().toISOString().slice(0,10), party_id:'', invoice_no:''})
  useEffect(()=>{(async()=>{ setRows(await db.invoices.toArray()); setParties(await db.parties.toArray()) })()},[])
  const totals = useMemo(()=>{
    const subtotal = items.reduce((a,i)=> a + (i.weight_g* (i.rate_per_g_inr||0)) + (i.making_rate_type==='per_g' ? i.making_rate_value*(i.weight_g||0) : (i.making_rate_value||0)), 0)
    const tax = Math.round(subtotal*0.03) // placeholder GST 3%
    const total = subtotal + tax
    return {subtotal, tax, total}
  },[items])

  function updateItem(idx, patch){
    const next = items.slice(); next[idx] = {...next[idx], ...patch}; setItems(next)
  }

  async function add(){
    const payload = { ...form, party_id:Number(form.party_id), subtotal_inr:totals.subtotal, discount_inr:0, tax_inr:totals.tax, total_inr:totals.total, received_inr:totals.total, balance_inr:0 }
    const id = await db.invoices.add(payload)
    setRows([...rows, {...payload, id}])
    setForm({date:new Date().toISOString().slice(0,10), party_id:'', invoice_no:String((rows.length+1)).padStart(4,'0')})
  }

  function pdf(inv){
    const doc = new jsPDF()
    doc.setFontSize(14)
    doc.text('Jewellery Rojmel – Invoice', 14, 16)
    const party = parties.find(p=>p.id===inv.party_id)
    doc.setFontSize(11)
    doc.text(`Invoice: ${inv.invoice_no}`, 14, 26)
    doc.text(`Date: ${inv.date}`, 120, 26)
    doc.text(`Party: ${party?party.name:''}`, 14, 34)
    doc.text(`Total: ₹${Math.round(inv.total_inr)}`, 14, 42)
    doc.text('Thank you for your business!', 14, 54)
    doc.save(`invoice_${inv.invoice_no}.pdf`)
  }

  return (
    <div className="grid">
      <div className="card">
        <div className="row">
          <div className="stack"><label>Invoice No</label><input className="input" value={form.invoice_no} onChange={e=>setForm({...form,invoice_no:e.target.value})}/></div>
          <div className="stack"><label>Date</label><input className="input" type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></div>
          <div className="stack" style={{flex:1}}><label>Party</label>
            <select className="select" value={form.party_id} onChange={e=>setForm({...form,party_id:e.target.value})}>
              <option value="">Select party</option>
              {parties.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
        </div>

        <div className="card" style={{marginTop:12}}>
          <table className="table">
            <thead><tr><th>Item</th><th>Metal</th><th>Purity</th><th>Weight (g)</th><th>Qty</th><th>Rate ₹/g</th><th>Making</th></tr></thead>
            <tbody>
              {items.map((it, idx)=>(
                <tr key={idx}>
                  <td><input className="input" value={it.item_name} onChange={e=>updateItem(idx,{item_name:e.target.value})}/></td>
                  <td>
                    <select className="select" value={it.metal_type} onChange={e=>updateItem(idx,{metal_type:e.target.value})}><option>Gold</option><option>Silver</option><option>Platinum</option><option>Diamond</option></select>
                  </td>
                  <td><input className="input" type="number" value={it.purity_kt} onChange={e=>updateItem(idx,{purity_kt:Number(e.target.value)})}/></td>
                  <td><input className="input" type="number" value={it.weight_g} onChange={e=>updateItem(idx,{weight_g:Number(e.target.value)})}/></td>
                  <td><input className="input" type="number" value={it.quantity} onChange={e=>updateItem(idx,{quantity:Number(e.target.value)})}/></td>
                  <td><input className="input" type="number" value={it.rate_per_g_inr||0} onChange={e=>updateItem(idx,{rate_per_g_inr:Number(e.target.value)})}/></td>
                  <td>
                    <select className="select" value={it.making_rate_type} onChange={e=>updateItem(idx,{making_rate_type:e.target.value})}>
                      <option value="per_g">Per g</option><option value="fixed">Fixed</option>
                    </select>
                    <input className="input" type="number" value={it.making_rate_value||0} onChange={e=>updateItem(idx,{making_rate_value:Number(e.target.value)})}/>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="row" style={{marginTop:12}}>
          <div className="card" style={{flex:1}}>
            <div className="stack">
              <div className="muted">Subtotal</div><strong>₹{Math.round(totals.subtotal)}</strong>
              <div className="muted">GST (3% demo)</div><strong>₹{Math.round(totals.tax)}</strong>
              <div className="muted">Total</div><strong>₹{Math.round(totals.total)}</strong>
            </div>
          </div>
          <div className="right"><button className="btn primary" onClick={add}>Save Invoice</button></div>
        </div>
      </div>

      <div className="card">
        <table className="table"><thead><tr><th>No</th><th>Date</th><th>Party</th><th>Total</th><th></th></tr></thead>
          <tbody>
            {rows.map(r=>(<tr key={r.id}><td>{r.invoice_no}</td><td>{r.date}</td><td>{(parties.find(p=>p.id===r.party_id)||{}).name||'-'}</td><td>₹{Math.round(r.total_inr)}</td>
              <td><button className="btn" onClick={()=>pdf(r)}>PDF</button></td></tr>))}
            {rows.length===0 && <tr><td colSpan="5" className="muted">No invoices yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  )
}
