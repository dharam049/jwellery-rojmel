import React, { useEffect, useState } from 'react'
import { db } from '../db'

export default function Dashboard(){
  const [stats, setStats] = useState({jamaa:0, naama:0, today:0})
  useEffect(()=>{(async()=>{
    const tx = await db.transactions.toArray()
    let j=0,n=0; 
    const today = new Date().toISOString().slice(0,10)
    let t=0
    tx.forEach(r=>{
      if(r.jamaa_or_naama==='receipt') j+=Number(r.amount_inr||0)
      else n+=Number(r.amount_inr||0)
      if(r.date===today) t++
    })
    setStats({jamaa:j, naama:n, today:t})
  })()},[])
  const currency = n=> new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR'}).format(n||0)
  return (
    <div className="grid cols-4">
      <div className="card"><div className="muted">Total Jamaa</div><h2>{currency(stats.jamaa)}</h2></div>
      <div className="card"><div className="muted">Total Naama</div><h2>{currency(stats.naama)}</h2></div>
      <div className="card"><div className="muted">Net Balance</div><h2>{currency(stats.jamaa-stats.naama)}</h2></div>
      <div className="card"><div className="muted">Today’s Transactions</div><h2>{stats.today}</h2></div>
    </div>
  )
}
