import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../auth'

export default function Login(){
  const { login } = useAuth()
  const nav = useNavigate()
  const [mobile, setMobile] = useState('9999999999')
  const [pin, setPin] = useState('1234')
  const [err, setErr] = useState('')
  async function submit(e){
    e.preventDefault()
    try{ await login(mobile, pin); nav('/') } catch(e){ setErr('Invalid mobile or PIN') }
  }
  return (
    <form className="card" onSubmit={submit} style={{maxWidth:420, margin:'24px auto'}}>
      <h2>PIN Login</h2>
      <div className="stack"><label>Mobile</label><input className="input" value={mobile} onChange={e=>setMobile(e.target.value)}/></div>
      <div className="stack"><label>PIN</label><input className="input" value={pin} onChange={e=>setPin(e.target.value)} type="password"/></div>
      {err && <div className="badge" style={{color:'var(--danger)'}}>{err}</div>}
      <div className="right"><button className="btn primary" type="submit">Login</button></div>
      <div className="muted">Demo: 9999999999 / 1234</div>
    </form>
  )
}
