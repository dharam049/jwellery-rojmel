import React, { useEffect, useState } from 'react'
import { db } from '../db'

export default function Parties(){
  const [rows, setRows] = useState([])
  const [form, setForm] = useState({name:'', type:'customer', phone:'', gstin:'', opening_balance:0})
  useEffect(()=>{(async()=> setRows(await db.parties.toArray()))()},[])
  async function add(){
    const now = new Date().toISOString()
    const id = await db.parties.add({...form, opening_balance:Number(form.opening_balance||0), current_balance:Number(form.opening_balance||0), created_at:now, updated_at:now})
    setRows([...rows, {...form, id}])
    setForm({name:'', type:'customer', phone:'', gstin:'', opening_balance:0})
  }
  async function remove(id){
    await db.parties.delete(id); setRows(rows.filter(r=>r.id!==id))
  }
  return (
    <div className="grid">
      <div className="card">
        <div className="row">
          <div className="stack"><label>Name</label><input className="input" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></div>
          <div className="stack"><label>Type</label>
            <select className="select" value={form.type} onChange={e=>setForm({...form,type:e.target.value})}><option>customer</option><option>supplier</option><option>karigar</option></select>
          </div>
          <div className="stack"><label>Phone</label><input className="input" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></div>
          <div className="stack"><label>GSTIN</label><input className="input" value={form.gstin} onChange={e=>setForm({...form,gstin:e.target.value})}/></div>
          <div className="stack"><label>Opening Balance</label><input className="input" type="number" value={form.opening_balance} onChange={e=>setForm({...form,opening_balance:e.target.value})}/></div>
          <div className="right"><button className="btn primary" onClick={add}>Add Party</button></div>
        </div>
      </div>
      <div className="card">
        <table className="table"><thead><tr><th>Name</th><th>Type</th><th>Phone</th><th>GSTIN</th><th>Balance</th><th></th></tr></thead>
        <tbody>
          {rows.map(r=>(<tr key={r.id}><td>{r.name}</td><td>{r.type}</td><td>{r.phone}</td><td>{r.gstin}</td><td>{r.current_balance||0}</td>
            <td><button className="btn danger" onClick={()=>remove(r.id)}>Delete</button></td></tr>))}
          {rows.length===0 && <tr><td colSpan="6" className="muted">No parties yet.</td></tr>}
        </tbody></table>
      </div>
    </div>
  )
}
