import React, { useEffect, useState } from 'react'
import { db } from '../db'

export default function MetalRates(){
  const [rows, setRows] = useState([])
  const [form, setForm] = useState({date:new Date().toISOString().slice(0,10), metal_type:'Gold', purity_kt:22, rate_per_g_inr:6200})
  useEffect(()=>{(async()=> setRows(await db.metalRates.toArray()))()},[])
  async function add(){
    const id = await db.metalRates.add({...form, purity_kt:Number(form.purity_kt), rate_per_g_inr:Number(form.rate_per_g_inr)})
    setRows([...rows,{...form,id}])
  }
  async function remove(id){ await db.metalRates.delete(id); setRows(rows.filter(r=>r.id!==id)) }
  return (
    <div className="grid">
      <div className="card">
        <div className="row">
          <div className="stack"><label>Date</label><input className="input" type="date" value={form.date} onChange={e=>setForm({...form,date:e.target.value})}/></div>
          <div className="stack"><label>Metal</label>
            <select className="select" value={form.metal_type} onChange={e=>setForm({...form,metal_type:e.target.value})}><option>Gold</option><option>Silver</option><option>Diamond</option><option>Platinum</option></select>
          </div>
          <div className="stack"><label>Purity</label><input className="input" type="number" value={form.purity_kt} onChange={e=>setForm({...form,purity_kt:e.target.value})}/></div>
          <div className="stack"><label>Rate ₹/g</label><input className="input" type="number" value={form.rate_per_g_inr} onChange={e=>setForm({...form,rate_per_g_inr:e.target.value})}/></div>
          <div className="right"><button className="btn primary" onClick={add}>Add Rate</button></div>
        </div>
      </div>
      <div className="card">
        <table className="table"><thead><tr><th>Date</th><th>Metal</th><th>Purity</th><th>Rate ₹/g</th><th></th></tr></thead>
        <tbody>
          {rows.map(r=>(<tr key={r.id}><td>{r.date}</td><td>{r.metal_type}</td><td>{r.purity_kt}</td><td>{r.rate_per_g_inr}</td><td><button className="btn danger" onClick={()=>remove(r.id)}>Delete</button></td></tr>))}
          {rows.length===0 && <tr><td colSpan="5" className="muted">No rates yet.</td></tr>}
        </tbody></table>
      </div>
    </div>
  )
}
