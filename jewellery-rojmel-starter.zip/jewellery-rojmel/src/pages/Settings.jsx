import React from 'react'
export default function Settings(){
  return (
    <div className="grid cols-2">
      <div className="card">
        <div className="stack">
          <h3>Business Profile</h3>
          <input className="input" placeholder="Shop name"/>
          <input className="input" placeholder="GSTIN"/>
          <input className="input" placeholder="Phone"/>
        </div>
      </div>
      <div className="card">
        <div className="stack">
          <h3>Theme</h3>
          <div className="row">
            <button className="btn">Light</button>
            <button className="btn">Dark</button>
          </div>
        </div>
      </div>
    </div>
  )
}
